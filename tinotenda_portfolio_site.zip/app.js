const TinotendaPortfolio = () => (
  React.createElement('div', { className: 'min-h-screen bg-gradient-to-b from-gray-900 to-black text-white font-sans p-6' },
    React.createElement('div', { className: 'max-w-5xl mx-auto' },
      React.createElement('section', { className: 'text-center mb-16' },
        React.createElement('h1', { className: 'text-5xl font-bold' }, 'Tinotenda Chitanda'),
        React.createElement('p', { className: 'text-xl text-gray-400 mt-3' }, 'Learning Technologist | Sales & Client Success Specialist | LLB Candidate'),
        React.createElement('p', { className: 'italic text-teal-400 mt-4' }, '"Bridging Law, Learning, and Business to Build the Future."')
      ),
      React.createElement('section', { className: 'mb-14' },
        React.createElement('h2', { className: 'text-3xl font-semibold border-b border-gray-700 pb-2 mb-4' }, 'About Me'),
        React.createElement('p', { className: 'text-gray-300 leading-relaxed' },
          'I am a results-driven professional at the intersection of law, education, and technology. Currently pursuing my LLB at the University of the Western Cape...'
        )
      )
    )
  )
);

ReactDOM.render(React.createElement(TinotendaPortfolio), document.getElementById('root'));